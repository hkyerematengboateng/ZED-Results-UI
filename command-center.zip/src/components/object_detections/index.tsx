import React, { useState, useEffect } from 'react';
import { Container, Typography, List, ListItem, ListItemText } from '@mui/material';
import Alert from '@mui/material/Alert';
import {DataGrid} from '@mui/x-data-grid'


const columns = [
    {field: 'PredictedClass', headerName: 'Predicted Class',flex: 0.5,minWidth: 5, },
    { field: 'Softmax', headerName: 'Prediction Probability (%)',flex: 0.5,minWidth: 5,align: 'center' },
    // { field: 'audio_start_time', headerName: 'Audio Start time',flex: 0.5,minWidth: 5, },
    // { field: 'audio_end_time', headerName: 'Audio end time',flex: 0.5,minWidth: 5, },
    // { field: 'location', headerName: 'Location',flex: 0.5,minWidth: 5, renderCell:displayGeoLocation}
  ]
function DetectionResultsPage(){
    const [results, setResults] = useState([] as string[]);
    const [socketStatus, setSocketStatus] = useState('closing')
    const [prevResults, setPrevResults] = useState([] as any);
    useEffect(() => {
        if (socketStatus == 'closing') {
            connectSocket()
            setSocketStatus('opening')
        }
      }, [socketStatus]);

    function connectSocket(){
        const socket = new WebSocket('ws://localhost:8000');

        socket.onopen = () => {
          console.log('WebSocket connection established');
        };
    
        socket.onmessage = (event) => {

          const newResult = JSON.parse(event.data);
          console.log(newResult)
          setPrevResults((prevResults: any) => [...prevResults, newResult]);
        };
    
        socket.onclose = function(e) {
            console.log('Socket is closed. Reconnect will be attempted in 1 second.', e.reason);
            setTimeout(function() {
                setSocketStatus('closing')
            }, 1000);
          };
        // socket.onclose = () => {
        //   console.log('WebSocket connection closed');
        // };       
    }
    let counter = 0
function getRowIndex(){
  counter = counter +1 
  return counter
}
    return (
        <Container maxWidth="md" style={{ marginTop: '2rem' }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Results
        </Typography>
        <List>
          {prevResults.map((result: any, index: React.Key | null | undefined) => (
            <ListItem key={index}>
              <ListItemText primary={`Detected Class: ${result.predicted_class} Detection Confidence Score: ${result.pred_conf}`} />
            </ListItem>
          ))}
        </List>

      </Container>
    )
}
export default DetectionResultsPage